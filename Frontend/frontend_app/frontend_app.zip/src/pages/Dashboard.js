import React from "react";
import Header from "../components/Header";

const Dashboard = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default Dashboard;
